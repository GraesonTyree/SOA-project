
"""
Project 
CMSC355 Spring 2022
Derek Yuen

"""
import sys, subprocess, shlex

DEBUGPrint = 0 #used for debugging, checking the content of the Option.txt file.
OptionFileName = "TextFolder\\Option.txt"
MSGFileName = ""

with open(OptionFileName, 'r') as f:
    MSGFileName = f.readline().strip()
    
    if DEBUGPrint: #!DEBUG!#
        print("Content: ", MSGFileName, sep="",end="")

#The sys.argv[1] is the Error code.
args = "ServiceBroker.py" + " " + "TextBroker" + " " + MSGFileName + " " + sys.argv[1]
sb = subprocess.run(args, shell = True, stdout = subprocess.PIPE)
out = sb.stdout.strip().decode()
print(out)